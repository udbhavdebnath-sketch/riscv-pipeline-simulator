#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "cpu_state.h"
#include "memory.h"
#include "isa_registry.h"
#include "rv32i_base.h"
#include "rv32m.h"
#include "zicsr.h"
#include "rv32f.h"
#include "assembler.h"
#include "cli_display.h"
#include "pipeline_state.h"
#include "hazard.h"
#include "branch_predictor.h"

#define DEFAULT_MEM_SIZE   (1u << 20)   /* 1 MB */
#define DEFAULT_MAX_CYCLES 1000000ull

static void usage(const char *prog) {
    fprintf(stderr,
        "usage: %s <program.s> [options]\n"
        "  --batch              run to completion with no interaction, then dump state\n"
        "  --single-cycle       with --batch: run the single-cycle reference instead of the pipeline\n"
        "  --hazard none|stall|forward  hazard unit for the pipeline (default forward)\n"
        "  --predictor not-taken|btfn|1bit|2bit  branch predictor (default 2bit)\n"
        "  --trace              print one line per pipeline cycle\n"
        "  --max-cycles N       cycle limit for --batch mode (default %llu)\n"
        "  --mem-size N         memory size in bytes (default %u)\n",
        prog, (unsigned long long)DEFAULT_MAX_CYCLES, DEFAULT_MEM_SIZE);
}

int main(int argc, char **argv) {
    if (argc < 2) {
        usage(argv[0]);
        return 1;
    }

    const char *program_path = argv[1];
    int batch_mode = 0, single_cycle = 0, trace = 0;
    const HazardUnit *hz = &hazard_forward;
    const BranchPredictor *bp = &bp_2bit;
    uint64_t max_cycles = DEFAULT_MAX_CYCLES;
    uint32_t mem_size = DEFAULT_MEM_SIZE;

    for (int i = 2; i < argc; i++) {
        if (strcmp(argv[i], "--batch") == 0) {
            batch_mode = 1;
        } else if (strcmp(argv[i], "--pipeline") == 0) {
            batch_mode = 1;                 /* Lab 2 spelling: the pipeline is now the default */
        } else if (strcmp(argv[i], "--single-cycle") == 0) {
            batch_mode = 1; single_cycle = 1;
        } else if (strcmp(argv[i], "--hazard") == 0 && i + 1 < argc) {
            if (!(hz = hazard_find(argv[++i]))) {
                fprintf(stderr, "unknown hazard unit '%s' (none|stall|forward)\n", argv[i]);
                return 1;
            }
        } else if (strcmp(argv[i], "--trace") == 0) {
            trace = 1;
        } else if (strcmp(argv[i], "--predictor") == 0 && i + 1 < argc) {
            if (!(bp = bp_find(argv[++i]))) {
                fprintf(stderr, "unknown predictor '%s' (not-taken|btfn|1bit|2bit)\n", argv[i]);
                return 1;
            }
        } else if (strcmp(argv[i], "--max-cycles") == 0 && i + 1 < argc) {
            max_cycles = strtoull(argv[++i], NULL, 0);
        } else if (strcmp(argv[i], "--mem-size") == 0 && i + 1 < argc) {
            mem_size = (uint32_t)strtoul(argv[++i], NULL, 0);
        } else {
            fprintf(stderr, "unrecognized option '%s'\n", argv[i]);
            usage(argv[0]);
            return 1;
        }
    }

    /* 1. Bring up the ISA. Later labs add their own register_rv32m(),
     *    register_rv32f(), register_custom_ext(), etc. right here. */
    isa_registry_init();
    register_rv32i_base();
    register_rv32m();
    register_zicsr();
    register_rv32f();

    /* 2. Set up memory and assemble the program into it. */
    Memory mem;
    if (memory_init(&mem, mem_size) != 0) {
        fprintf(stderr, "error: could not allocate %u bytes of simulated memory\n", mem_size);
        return 1;
    }

    uint32_t entry_point = 0;
    AsmError err;
    AsmStatus asm_status = assemble_file(program_path, &mem, &entry_point, &err);
    if (asm_status != ASM_OK) {
        fprintf(stderr, "assembly error");
        if (err.line_number > 0) fprintf(stderr, " (line %d)", err.line_number);
        fprintf(stderr, ": %s\n", err.message);
        memory_free(&mem);
        return 1;
    }

    printf("assembled '%s' ok. entry point = 0x%08x\n", program_path, entry_point);

    /* 3. Reset the CPU at the program's entry point and run it. */
    CPUState cpu;
    cpu_reset(&cpu, entry_point);

    SimEngine engine;
    Pipeline pipe;
    if (!single_cycle) {
        pipeline_init(&pipe, hz, bp);
        pipeline_make_engine(&engine, &pipe, &cpu, &mem);
    } else {
        sim_engine_single_cycle(&engine, &cpu, &mem);
    }
    if (batch_mode) run_batch(&engine, max_cycles, trace);
    else run_repl(&engine);

    memory_free(&mem);
    return 0;
}
